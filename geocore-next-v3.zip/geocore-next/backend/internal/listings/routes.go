package listings

import (
	"github.com/geocore-next/backend/pkg/middleware"
	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"gorm.io/gorm"
)

func RegisterRoutes(r *gin.RouterGroup, db *gorm.DB, rdb *redis.Client) {
	h := NewHandler(db, rdb)

	r.GET("/categories", h.GetCategories)

	listings := r.Group("/listings")
	{
		listings.GET("", h.List)
		listings.GET("/:id", h.Get)

		// Authenticated routes
		auth := listings.Group("")
		auth.Use(middleware.Auth())
		auth.POST("", h.Create)
		auth.GET("/me", h.GetMyListings)      // must be in auth group, registered before /:id actions
		auth.PUT("/:id", h.Update)
		auth.DELETE("/:id", h.Delete)
		auth.POST("/:id/favorite", h.ToggleFavorite)
	}
}
