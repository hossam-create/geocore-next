package users

import (
	"github.com/geocore-next/backend/pkg/middleware"
	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"gorm.io/gorm"
)

func RegisterRoutes(r *gin.RouterGroup, db *gorm.DB, rdb *redis.Client) {
	h := NewHandler(db, rdb)
	users := r.Group("/users")
	{
		// Authenticated self routes — must come before /:id to avoid "me" being treated as an id
		me := users.Group("/me")
		me.Use(middleware.Auth())
		me.GET("", h.GetMe)
		me.PUT("", h.UpdateMe)

		// Public profile — after /me group
		users.GET("/:id/profile", h.GetProfile)
	}
}
