package auctions

import (
	"fmt"
	"strconv"
	"time"

	"github.com/geocore-next/backend/pkg/response"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
	"gorm.io/gorm"
)

type Handler struct {
	db  *gorm.DB
	rdb *redis.Client
	hub *Hub
}

func NewHandler(db *gorm.DB, rdb *redis.Client, hub *Hub) *Handler {
	return &Handler{db, rdb, hub}
}

func (h *Handler) List(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage := 20
	var auctions []Auction
	var total int64
	q := h.db.Model(&Auction{}).Where("status = ? AND ends_at > ?", "active", time.Now())
	q.Count(&total)
	q.Preload("Bids").Offset((page-1)*perPage).Limit(perPage).
		Order("ends_at ASC").Find(&auctions)
	response.OKMeta(c, auctions, gin.H{"total": total, "page": page})
}

func (h *Handler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "Invalid ID")
		return
	}
	var auction Auction
	if err := h.db.Preload("Bids", func(db *gorm.DB) *gorm.DB {
		return db.Order("amount DESC").Limit(20)
	}).First(&auction, "id = ?", id).Error; err != nil {
		response.NotFound(c, "Auction")
		return
	}
	response.OK(c, auction)
}

func (h *Handler) Create(c *gin.Context) {
	sellerID, _ := uuid.Parse(c.MustGet("user_id").(string))
	var req struct {
		ListingID    string   `json:"listing_id" binding:"required"`
		StartPrice   float64  `json:"start_price" binding:"required,min=0"`
		ReservePrice *float64 `json:"reserve_price"`
		BuyNowPrice  *float64 `json:"buy_now_price"`
		Currency     string   `json:"currency"`
		DurationHrs  int      `json:"duration_hours" binding:"required,min=1,max=720"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	listingID, _ := uuid.Parse(req.ListingID)
	now := time.Now()
	auction := Auction{
		ID:           uuid.New(),
		ListingID:    listingID,
		SellerID:     sellerID,
		StartPrice:   req.StartPrice,
		ReservePrice: req.ReservePrice,
		BuyNowPrice:  req.BuyNowPrice,
		CurrentBid:   0,
		Currency:     defaultStr(req.Currency, "USD"),
		Status:       "active",
		StartsAt:     now,
		EndsAt:       now.Add(time.Duration(req.DurationHrs) * time.Hour),
	}
	if err := h.db.Create(&auction).Error; err != nil {
		response.InternalError(c, err)
		return
	}
	response.Created(c, auction)
}

func (h *Handler) PlaceBid(c *gin.Context) {
	userID, _ := uuid.Parse(c.MustGet("user_id").(string))
	auctionID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "Invalid ID")
		return
	}

	var req struct {
		Amount    float64  `json:"amount" binding:"required"`
		IsAuto    bool     `json:"is_auto"`
		MaxAmount *float64 `json:"max_amount"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}

	var bid Bid
	var auction Auction

	txErr := h.db.Transaction(func(tx *gorm.DB) error {
		// Lock the row so concurrent bids are serialised
		if err := tx.Set("gorm:query_option", "FOR UPDATE").
			First(&auction, "id = ? AND status = ?", auctionID, "active").Error; err != nil {
			return fmt.Errorf("auction not found: %w", err)
		}

		if time.Now().After(auction.EndsAt) {
			return fmt.Errorf("auction has ended")
		}
		if auction.SellerID == userID {
			return fmt.Errorf("cannot bid on your own auction")
		}

		minBid := auction.CurrentBid
		if auction.BidCount == 0 {
			minBid = auction.StartPrice - 0.01
		}
		if req.Amount <= minBid {
			return fmt.Errorf("bid must be higher than %.2f", minBid)
		}

		bid = Bid{
			ID:        uuid.New(),
			AuctionID: auctionID,
			UserID:    userID,
			Amount:    req.Amount,
			IsAuto:    req.IsAuto,
			MaxAmount: req.MaxAmount,
			PlacedAt:  time.Now(),
		}
		if err := tx.Create(&bid).Error; err != nil {
			return fmt.Errorf("create bid: %w", err)
		}
		if err := tx.Model(&auction).Updates(map[string]interface{}{
			"current_bid": req.Amount,
			"bid_count":   gorm.Expr("bid_count + 1"),
		}).Error; err != nil {
			return fmt.Errorf("update auction: %w", err)
		}

		// Anti-sniping: extend by 5 min if bid lands in last 5 min
		if time.Until(auction.EndsAt) < 5*time.Minute {
			newEnd := auction.EndsAt.Add(5 * time.Minute)
			if err := tx.Model(&auction).Update("ends_at", newEnd).Error; err != nil {
				return fmt.Errorf("extend auction: %w", err)
			}
			auction.EndsAt = newEnd
		}

		return nil
	})

	if txErr != nil {
		msg := txErr.Error()
		switch msg {
		case "auction has ended", "cannot bid on your own auction":
			response.BadRequest(c, msg)
		default:
			if len(msg) > 15 && msg[:15] == "bid must be hig" {
				response.BadRequest(c, msg)
			} else if msg == "auction not found: record not found" {
				response.NotFound(c, "Auction")
			} else {
				response.InternalError(c, txErr)
			}
		}
		return
	}

	// Push to Hub for WebSocket broadcast (BUG 4 fix applied in websocket.go)
	if h.hub != nil {
		payload := fmt.Sprintf(
			`{"type":"bid_update","auction_id":"%s","current_bid":%.2f,"bid_count":%d,"ends_at":"%s"}`,
			auctionID, auction.CurrentBid+req.Amount, auction.BidCount+1, auction.EndsAt.Format(time.RFC3339),
		)
		h.hub.broadcast <- &BroadcastMsg{AuctionID: auctionID.String(), Data: []byte(payload)}
	}

	response.Created(c, bid)
}

func (h *Handler) GetBids(c *gin.Context) {
	id, _ := uuid.Parse(c.Param("id"))
	var bids []Bid
	h.db.Where("auction_id = ?", id).Order("amount DESC").Limit(50).Find(&bids)
	response.OK(c, bids)
}

func defaultStr(s, d string) string {
	if s == "" { return d }
	return s
}
