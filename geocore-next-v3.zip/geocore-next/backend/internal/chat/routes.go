package chat

import (
	"github.com/geocore-next/backend/pkg/middleware"
	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"gorm.io/gorm"
)

// RegisterRoutes receives the shared Hub created in main.go.
// BUG 3 fix: previously created its own Hub here → duplicate, disconnected from main hub.
func RegisterRoutes(r *gin.RouterGroup, db *gorm.DB, rdb *redis.Client, hub *Hub) {
	h := NewHandler(db, rdb, hub)

	g := r.Group("/chat", middleware.Auth())
	{
		g.GET("/conversations", h.GetConversations)
		g.POST("/conversations", h.CreateOrGetConversation)
		g.GET("/conversations/:id/messages", h.GetMessages)
		g.POST("/conversations/:id/messages", h.SendMessage)
		g.GET("/conversations/:id/ws", func(c *gin.Context) {
			ServeWS(hub, c, db)
		})
	}
}
